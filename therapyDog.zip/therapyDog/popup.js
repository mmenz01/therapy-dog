document.getElementById("button").addEventListener("click", changeImage);
function changeImage()
        {
        var img = document.getElementById("image");
        img.src="heartdog.jpeg";
        return false;
        }
